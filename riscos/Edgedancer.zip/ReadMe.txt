                   _             __    /~\       __
                  / \  ___ _____/ (__ /___\ ____ ) \__
               . /___\/x__\)  __\ .  \_ ___/ x  \  _  \ .
              :::___ / \/  \  _\ \ x   \   \     ) /   \:::.
             :::/    \______|____/_____/____\_/  \_____/::::.
         ------/______|-----  presents   -----\___\------------
                              _    __

                         -================-
                         =-{ Edgedancer }-=
                         -================-

a 90 byte intro by exoticorn/icebird for RISC OS on modern hardware, for
example Raspberry PI 2 or later. It requires a CPU which supports the Thumb-2
instruction set. The target platform is a Raspberry Pi 3B+ where it runs at a
reasonable framerate.

This is the final version, the party version was shown at Outline Online 2020
and was pretty much unoptimized 112 bytes. To exit this intro you need to
kill it using alt+break.

NOTES: This intro runs in 320x256 (Mode 13, for those who still remember the
       Acorn Archimedes days), so you'll have to make sure your system supports
       this resolution. The easiest way to do so is to have
       'disable_mode_changes' in your cmdline.txt and to have the 'anymode'
       module loaded. RISC OS Direct comes set up like this, so if you are
       running Direct and haven't changed the cmdline.txt you should already
       be good to go.
       This intro uses Thumb mode (16bit instructions, rather than the original
       32bit ARM instructions) and does system calls from this mode. RISC OS
       fully supports this, but a commonly used 3rd party module called
       SpecialFX intercepts system calls (mostly to force enable anti-aliasing
       in old applications) and is not Thumb aware. So having this module loaded
       causes the intro to crash immediately. A simple 'RMKill SpecialFX'
       remedies this. I have also provided an Obey file you can run which does
       just that.

Bonus versions:
---------------

EdgeARM:       ARM mode version in 128 bytes. Runs (or possibly crawls) on every
               RISC OS machine out there. Showing that this intro can fit in
               128 bytes even without using Thumb.
EdgeARMSlow:   Somewhat pointless, half as fast as EdgeARM @ 124 bytes. Only
               neat thing about it is that it uses just a single branch
               instruction.
Edgedancer480: Same as the main version, only in 640x480. It's a little slow
               on my Pi 3B+, but according to Kuemmel, it's fast enough on a
               Pi 4.
EdgedancerCentered: The final version saves two bytes by not having the camera
               perfectly centered. This version looks identical to the
               party version at 92 bytes.
EdgedancerXS:  Saving two more bytes by throwing the correct aspect ratio
               out of the window.

Building the intro from source:
-------------------------------

To bulid the intro yourself, you'll have to first run !GCC to set the run-path
for the gcc binutils, then just run !BuildAndRun.

Special thanks have to go to:
-----------------------------

- giZMo/icebird for reminding me to do a backup of my old RiscPC HD before
  it is too late. Taking a look at my old code again inspired me to check out
  RISC OS on Raspberry PI.
- Kuemmel for his RISC OS 256 byte intro '3dball' @ Revision 2020 which also
  motivated me to release something for this platform again.
- Phlamethrower for pointing out (via Kuemmel) that RISC OS fully supports
  Thumb mode, as long as the 3rd party 'SpecialFX' module isn't running to
  mess things up.

Also a big thanks to anyone involved in keeping RISC OS alive, 20 years after
the death of Acorn. It still is a really fun platform to code on.

Contact: dennis.ranke@gmail.com
