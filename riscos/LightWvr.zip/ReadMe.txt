                   _             __    /~\       __
                  / \  ___ _____/ (__ /___\ ____ ) \__
               . /___\/x__\)  __\ .  \_ ___/ x  \  _  \ .
              :::___ / \/  \  _\ \ x   \   \     ) /   \:::.
             :::/    \______|____/_____/____\_/  \_____/::::.
         ------/______|-----  presents   -----\___\------------
                              _    __

                        -=================-
                        =-{ Lightweaver }-=
                        -=================-

a 256 byte intro by exoticorn/icebird for RISC OS. My contribution to the
code craft #4 competition.
The intro is designed to run in 320x256 at > 60fps on a StrongARM RiscPC
(ie. 1996 state of the art RISC OS hardware).

I included 4 versions for different RISC OS hardware:

LightWvr:
  320x256, for use on RiscPCs, StrongARM prefered.

LightWvrHi:
  640x512, for anything faster than a StrongARM, including rpcemu on a
  fast pc.

LightWvrLo:
  320x256, skipping every other line. For ARM3 and possibly ARM250.

LightWvrUL:
  320x256, skipping every other line AND every second pixel. The only way
  to get the effect to viewable speeds on ARM2.

Greetings go to Kuemmel for running cc#4, everyone still coding for RISC OS
and everyone on the sizecoding discord.